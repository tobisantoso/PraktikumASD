#include <stdio.h>
#include <stdlib.h>
#include "listlinier.c"

int main()
{
	
	/*infotype X;
	address P;
	int pil;
	scanf("%d".&pil);
	int a[999];
	for(int i=0;i<=n; i++){
		scanf("%d",&a[n]);
	}
	
	*/
	infotype PL,N,X;
	List L;
	address A;
	
	Alokasi(N);
	do{
		printf("1. isi nilai");
		printf("2. Print nilai");
		printf("3. hapus");
		scanf("%d",&PL);
		
		if(PL==1){
			printf("masukkan nilai:");
			scanf("%d",&N);
			InsVFirst(&L,N);
		}else if(PL==2){
			printf("Nilai dalam List:");
			PrintInfo(L);
		}else if(PL==3){
			printf("Nilai yang akan di hapus:");
			scanf("%d",&X);
			DelP(&L,X);
		}
	}while(PL!=0);
	}
	
		
	/*
	
	CreateEmpty(&L);
	scanf("masukkan banyak elemen:%d",&n);
	
	for(int i=0;i<=n;i++){
		printf("=%d",i);
		
		
	}
		PrintInfo(L);
	
	
	CreateEmpty (&A);
	CreateEmpty (&B);
	CreateEmpty (&C);
	InsVFirst (&A,X);
	InsVLast (&A,X);
	//DelVFirst (&A,&X);
	//DelVLast (&A,&X);
	PrintInfo (A);
	NbElmt (A);
	Konkat1 (&A,&B,&C);
	*/
	
