#include <stdlib.h>
#include <stdio.h>
#include "array.h"
#include "boolean.h"

/*Tobi Santoso*/
/*14115029*/

int main()
{
	TabInt Tobi;
	MakeEmpty(&Tobi);
	BacaIsi(&Tobi);
	TulisIsi(Tobi);
		
		int pil;
		scanf("%d",&pil);
		
		if(pil==1){
			printf("%d",ValMax(Tobi));
		}else if(pil==2){
			printf("%d",ValMin(Tobi));
		}else if(pil==3){
			printf("%d\n",ValMax(Tobi));
			printf("%d",ValMin(Tobi));
		}else{
			printf("Nilai Ekstrim tidak bisa dicari");
		}
		

	
	return 0;
}

