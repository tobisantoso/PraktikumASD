#include "point.h"
#include "point.c"
#include <stdio.h>

int main()
{
	POINT TOBI;
	MakePOINT(2,1);
	BacaPOINT(&TOBI);
	TulisPOINT(TOBI);

 
 return 0;
}

