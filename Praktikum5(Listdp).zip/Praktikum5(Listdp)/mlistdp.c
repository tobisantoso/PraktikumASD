#include "listdp.h"
#include <stdio.h>
#include <stdlib.h>

int main()
{
	List L;
	address P,Prec;
	infotype A,o;
	int n,i;
	CreateEmpty(&L);
	printf("Masukkan banyak isi dari List\n");
	printf("dari depan(InsVFirst)\n");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&A);
		Alokasi(A);
		InsVFirst(&L,A);
	}
	PrintForward(L);
	printf("\nHapus nilai awal\n");
	DelFirst(&L,&P);
	PrintForward(L);

   return 0;
}